#include "Game.hpp"
#include "ResourceManager.hpp"
#include <iostream>
#include <cmath>
#include <climits>

Game::Game(): window(sf::VideoMode(1024, 768), "MetroidvaniaLike") {
    window.setFramerateLimit(60);
    // font: try packaged font filename, fallback to common system path
    if(!font.loadFromFile("textures/arial.ttf")){
        // fallback common Linux path - many systems have DejaVuSans
        font.loadFromFile("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf");
    }

    auto npc = std::make_unique<NPC>("Добро пожаловать в Лес Теней! Найди 4 драконов...");
    npc->setPosition(200, 360);
    npcs.push_back(std::move(npc));

    // place player above the floor so they do not immediately fall
    player.setPosition(150, 620);

    bosses.emplace_back(std::make_unique<Boss>(BossDifficulty::Easy, "Drake A"));
    bosses.back()->setPosition(700, 260);

    bosses.emplace_back(std::make_unique<Boss>(BossDifficulty::Medium, "Drake B"));
    bosses.back()->setPosition(900, 260);

    bosses.emplace_back(std::make_unique<Boss>(BossDifficulty::Hard, "Ancient"));
    bosses.back()->setPosition(1200, 260);

    bosses.emplace_back(std::make_unique<Boss>(BossDifficulty::Expert, "Elder"));
    bosses.back()->setPosition(1500, 260);
}

void Game::run(){
    sf::Clock clock;
    while(window.isOpen()){
        float dt = clock.restart().asSeconds();
        processEvents();
        update(dt);
        render();
    }
}

void Game::processEvents(){
    sf::Event ev;
    while(window.pollEvent(ev)){
        if(ev.type == sf::Event::Closed) window.close();
        if(ev.type == sf::Event::KeyPressed){
            if(ev.key.code == sf::Keyboard::Tab) showMap = true;
            player.handleInput(ev.key.code, true);

            if(ev.key.code == sf::Keyboard::B){
                for(auto &bPtr : bosses){
                    if(std::abs(bPtr->getPosition().x - player.getPosition().x) < 200.f){
                        inBossPuzzle = true;
                        currentBoss = bPtr.get();
                        playerInput.clear();
                        break;
                    }
                }
            }
        }
        if(ev.type == sf::Event::KeyReleased){
            if(ev.key.code == sf::Keyboard::Tab) showMap = false;
            player.handleInput(ev.key.code, false);
        }

        if(inBossPuzzle && ev.type == sf::Event::TextEntered){
            if(ev.text.unicode >= '0' && ev.text.unicode <= '9') playerInput.push_back(static_cast<char>(ev.text.unicode));
            if(ev.text.unicode == '\b' && !playerInput.empty()) playerInput.pop_back();
            if(ev.text.unicode == '\r'){
                if(!currentBoss) { inBossPuzzle = false; continue; }
                int val = 0;
                try { val = std::stoi(playerInput); } catch(...) { val = INT_MIN; }
                if(val == currentBoss->getAnswer()){
                    std::cout << "Correct! fight starts with boss " << currentBoss->getName() << "\n";
                    currentBoss->onDamage(50);
                } else {
                    std::cout << "Wrong! you take damage.\n";
                    player.onDamage(20);
                }
                inBossPuzzle = false;
                currentBoss = nullptr;
            }
        }
    }
}

void Game::update(float dt){
    player.update(dt);
    for(auto &n : npcs) n->update(dt);
    for(auto &b : bosses) b->update(dt);
}

void Game::render(){
    window.clear();
    sf::Sprite bg(ResourceManager::getTexture("bg.png"));
    window.draw(bg);

    map.draw(window);

    for(auto &n : npcs) window.draw(*n);
    for(auto &b : bosses) window.draw(*b);
    window.draw(player);

    if(showMap){
        sf::RectangleShape overlay(sf::Vector2f(600, 400));
        overlay.setFillColor(sf::Color(0,0,0,150));
        overlay.setPosition(200, 150);
        window.draw(overlay);

        sf::Text t("Map (white arrow = you)", font, 18);
        t.setPosition(220, 160);
        window.draw(t);

        sf::CircleShape arrow(8);
        arrow.setFillColor(sf::Color::White);
        arrow.setPosition(240 + player.getPosition().x / 10.f, 200 + player.getPosition().y / 10.f);
        window.draw(arrow);
    }

    if(inBossPuzzle && currentBoss){
        sf::RectangleShape box(sf::Vector2f(500,150));
        box.setFillColor(sf::Color(0,0,0,200));
        box.setPosition(260, 300);
        window.draw(box);

        sf::Text prompt("Solve: " + currentBoss->getPrompt(), font, 24);
        prompt.setPosition(280, 320);
        window.draw(prompt);

        sf::Text input("Answer: " + playerInput, font, 20);
        input.setPosition(280, 360);
        window.draw(input);
    }

    window.display();
}
