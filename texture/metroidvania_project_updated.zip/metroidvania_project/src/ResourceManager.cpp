#include "ResourceManager.hpp"
#include <stdexcept>

std::unordered_map<std::string, std::unique_ptr<sf::Texture>> ResourceManager::textures;

sf::Texture& ResourceManager::getTexture(const std::string& filename){
    auto it = textures.find(filename);
    if(it != textures.end()) return *it->second;
    auto tex = std::make_unique<sf::Texture>();
    if(!tex->loadFromFile("textures/" + filename)){
        throw std::runtime_error("Failed to load texture: " + filename);
    }
    tex->setSmooth(true);
    textures[filename] = std::move(tex);
    return *textures[filename];
}
