#pragma once
#include "Entity.hpp"
#include <string>

enum class BossDifficulty { Easy = 0, Medium = 1, Hard = 2, Expert = 3 };

class Boss : public Entity {
public:
    Boss(BossDifficulty diff, const std::string& name);
    void update(float dt) override;
    bool startEncounter();
    const std::string& getPrompt() const { return prompt; }
    int getAnswer() const { return answer; }
    std::string getName() const { return name; }

    void takeTurn();
private:
    BossDifficulty difficulty;
    std::string name;
    std::string prompt;
    int answer;
    void generatePuzzle();
};
