#pragma once
#include <SFML/Graphics.hpp>
#include "Player.hpp"
#include "NPC.hpp"
#include "Boss.hpp"
#include "Map.hpp"
#include <vector>
#include <memory>

class Game {
public:
    Game();
    void run();

private:
    sf::RenderWindow window;
    Player player;
    Map map;
    std::vector<std::unique_ptr<NPC>> npcs;
    std::vector<std::unique_ptr<Boss>> bosses;

    bool showMap = false;

    void processEvents();
    void update(float dt);
    void render();

    bool inBossPuzzle = false;
    Boss* currentBoss = nullptr;
    std::string playerInput;
    sf::Font font;
};
