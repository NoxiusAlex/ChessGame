#include "NPC.hpp"
#include "ResourceManager.hpp"
#include <cmath>

NPC::NPC(const std::string& msg): message(msg) {
    setSpriteSheet(ResourceManager::getTexture("npc_talk.png"), 64, 64);
    setOrigin(32, 32);
}

void NPC::update(float dt){
    // idle bob (time-based)
    float bob = std::sin((float)clock() / 300.0f) * 0.5f;
    sprite.setPosition(0, bob);
}
