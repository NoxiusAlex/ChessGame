#pragma once
#include <SFML/Graphics.hpp>
#include <vector>

class Map {
public:
    Map();
    void draw(sf::RenderTarget& target);
    bool checkCollision(const sf::FloatRect& rect);
private:
    std::vector<sf::RectangleShape> platforms;
    sf::Texture& tileset;
};
