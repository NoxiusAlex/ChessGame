#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include <unordered_map>
#include <memory>

class ResourceManager {
public:
    static sf::Texture& getTexture(const std::string& filename);
private:
    static std::unordered_map<std::string, std::unique_ptr<sf::Texture>> textures;
};
