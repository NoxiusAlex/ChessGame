#pragma once
#include "Entity.hpp"
#include <SFML/Window.hpp>

class Player : public Entity {
public:
    Player();
    void update(float dt) override;

    void handleInput(const sf::Keyboard::Key& key, bool pressed);
    void startAttack();
    void startDash();

private:
    sf::Vector2f velocity;
    bool movingLeft = false, movingRight = false;
    bool attacking = false;
    bool dashing = false;
    float dashTimer = 0.f;
    float attackTimer = 0.f;

    void applyPhysics(float dt);
    void updateAnimation(float dt);
};
