#include "Player.hpp"
#include "ResourceManager.hpp"
#include <cmath>

Player::Player(){
    setSpriteSheet(ResourceManager::getTexture("player_idle.png"), 64, 64);
    hp = 100;
    setOrigin(32, 32);
}

void Player::handleInput(const sf::Keyboard::Key& key, bool pressed){
    if(key == sf::Keyboard::Left) movingLeft = pressed;
    if(key == sf::Keyboard::Right) movingRight = pressed;
    if(key == sf::Keyboard::X && pressed) startAttack();
    if(key == sf::Keyboard::LShift && pressed) startDash();
    if(key == sf::Keyboard::Z && pressed){
        startAttack();
    }
}

void Player::startAttack(){
    if(!attacking){
        attacking = true;
        attackTimer = 0.35f;
    }
}

void Player::startDash(){
    if(!dashing){
        dashing = true;
        dashTimer = 0.2f;
        velocity.x += (movingRight - movingLeft) * 400.f;
    }
}

void Player::applyPhysics(float dt){
    float accel = 1000.f;
    float maxSpeed = 180.f;
    if(dashing) maxSpeed = 500.f;

    if(movingLeft) velocity.x -= accel * dt;
    if(movingRight) velocity.x += accel * dt;
    if(!movingLeft && !movingRight) velocity.x *= std::pow(0.001f, dt);

    if(std::abs(velocity.x) > maxSpeed) velocity.x = (velocity.x > 0 ? 1 : -1) * maxSpeed;

    velocity.y += 980.f * dt;

    move(velocity * dt);
}

void Player::updateAnimation(float dt){
    animTime += dt;
    if(animTime > 0.12f){
        animTime = 0.f;
        currentFrame = (currentFrame + 1) % framesCount;
        sprite.setTextureRect(sf::IntRect(currentFrame * frameW, 0, frameW, frameH));
    }
}

void Player::update(float dt){
    if(attacking){
        attackTimer -= dt;
        if(attackTimer <= 0) attacking = false;
    }
    if(dashing){
        dashTimer -= dt;
        if(dashTimer <= 0) dashing = false;
    }

    applyPhysics(dt);
    updateAnimation(dt);
}
