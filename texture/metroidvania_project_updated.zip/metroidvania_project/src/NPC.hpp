#pragma once
#include "Entity.hpp"
#include <string>

class NPC : public Entity {
public:
    NPC(const std::string& message);
    void update(float dt) override;
    const std::string& getMessage() const { return message; }
private:
    std::string message;
};
