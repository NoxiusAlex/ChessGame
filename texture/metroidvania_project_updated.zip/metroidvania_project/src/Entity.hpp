#pragma once
#include <SFML/Graphics.hpp>
#include <string>

class Entity : public sf::Drawable, public sf::Transformable {
public:
    Entity();
    virtual ~Entity() = default;

    virtual void update(float dt) = 0;
    virtual void onDamage(int amount);
    bool isAlive() const { return hp > 0; }

    // Animation helpers
    void setSpriteSheet(const sf::Texture& tex, int frameW, int frameH);

protected:
    int hp = 100;
    sf::Sprite sprite;
    int frameW = 0, frameH = 0;
    float animTime = 0.f;
    int currentFrame = 0;
    int framesCount = 1;

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
};
