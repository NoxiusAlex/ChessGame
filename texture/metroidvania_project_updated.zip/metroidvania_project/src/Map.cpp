#include "Map.hpp"
#include "ResourceManager.hpp"

Map::Map(): tileset(ResourceManager::getTexture("tileset.png")){
    sf::RectangleShape p1(sf::Vector2f(400, 48));
    p1.setPosition(100, 400);
    p1.setTexture(&tileset);
    platforms.push_back(p1);

    sf::RectangleShape p2(sf::Vector2f(200, 48));
    p2.setPosition(600, 300);
    p2.setTexture(&tileset);
    platforms.push_back(p2);
    // Bottom floor so the player doesn't fall through at start
    sf::RectangleShape floor(sf::Vector2f(2000, 64));
    floor.setPosition(-200, 704); // placed near bottom of 768 window
    floor.setTexture(&tileset);
    platforms.push_back(floor);
}

void Map::draw(sf::RenderTarget& target){
    for(auto &p : platforms) target.draw(p);
}

bool Map::checkCollision(const sf::FloatRect& rect){
    for(auto &p : platforms){
        if(p.getGlobalBounds().intersects(rect)) return true;
    }
    return false;
}
