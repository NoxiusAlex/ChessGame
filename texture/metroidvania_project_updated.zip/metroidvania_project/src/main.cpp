#include "Game.hpp"
#include <iostream>

int main(){
    try{
        Game game;
        game.run();
    } catch(std::exception& ex){
        std::cerr << "Error: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}
