#include "Boss.hpp"
#include "ResourceManager.hpp"
#include <random>
#include <sstream>
#include <cmath>
#include <ctime>

static std::mt19937 rng((unsigned)time(nullptr));

Boss::Boss(BossDifficulty diff, const std::string& name_): difficulty(diff), name(name_) {
    setSpriteSheet(ResourceManager::getTexture("boss1.png"), 128, 128);
    setOrigin(64, 64);
    generatePuzzle();
    hp = 200 + static_cast<int>(diff) * 100;
}

void Boss::generatePuzzle(){
    std::uniform_int_distribution<int> aDist(1, 10);
    int a = aDist(rng);
    int b = aDist(rng);
    switch(difficulty){
        case BossDifficulty::Easy:
            prompt = std::to_string(a) + " + " + std::to_string(b);
            answer = a + b;
            break;
        case BossDifficulty::Medium:
            prompt = std::to_string(a) + " * " + std::to_string(b);
            answer = a * b;
            break;
        case BossDifficulty::Hard:
            prompt = "log2(32)";
            answer = 5;
            break;
        case BossDifficulty::Expert:
            prompt = std::to_string(a*b) + " / " + std::to_string(a);
            answer = b;
            break;
    }
}

void Boss::update(float dt){
    // simple idle animation could be here
}

bool Boss::startEncounter(){
    generatePuzzle();
    return false;
}

void Boss::takeTurn(){
    // placeholder attack logic
}
