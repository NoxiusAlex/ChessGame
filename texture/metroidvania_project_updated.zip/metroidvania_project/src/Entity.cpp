#include "Entity.hpp"
#include <iostream>

Entity::Entity(){}

void Entity::onDamage(int amount){
    hp -= amount;
    if(hp < 0) hp = 0;
}

void Entity::setSpriteSheet(const sf::Texture& tex, int fw, int fh){
    sprite.setTexture(tex);
    frameW = fw; frameH = fh;
    sprite.setTextureRect(sf::IntRect(0,0,frameW,frameH));
    framesCount = tex.getSize().x / frameW;
}

void Entity::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    states.transform *= getTransform();
    target.draw(sprite, states);
}
