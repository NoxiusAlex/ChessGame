Metroidvania-like sample project (placeholder assets)
- Build with CMake and SFML 2.5+
- Put SFML development libraries installed (system package or manual)
- On Linux, you can often: sudo apt install libsfml-dev
- Build:
    mkdir build
    cd build
    cmake ..
    make
    ./MetroidvaniaLike
Controls:
- Left / Right arrows: move
- X or Z: attack
- Left Shift: dash
- Tab: open map
- B: start boss puzzle (when near a boss), type numbers and Enter to answer.
Textures are in textures/ (auto-generated placeholders). Replace them with your own assets.
